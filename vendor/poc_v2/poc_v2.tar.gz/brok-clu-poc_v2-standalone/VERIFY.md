# Verification Semantics

This document specifies the exact verification behavior of the PoC v2 standalone bundle.

## Verification Gate

The bundle enforces a verification-first model:

1. **Verification MUST pass before any execution**
2. **The run.sh script refuses to execute without prior verification**
3. **Verification status is checked by reading `bundles/verified/verify.status.txt`**
4. **Only the exact content `OK` (with optional trailing newline) indicates success**

## Verification Process

### Step 1: Check Verification Files

The following files MUST exist:

- `MANIFEST.txt` - List of all files in the bundle
- `SHA256SUMS` - SHA256 checksums for integrity verification

If either is missing, verification fails immediately.

### Step 2: Check Manifest Files

Every file listed in `MANIFEST.txt` MUST exist in the bundle. If any file is missing, verification fails.

### Step 3: Verify Checksums

Every entry in `SHA256SUMS` is verified:

1. Parse the expected hash and file path
2. Compute the actual SHA256 hash of the file
3. Compare expected vs actual

If any checksum mismatches, verification fails.

### Step 4: Check Required Runtime Files

The following files MUST exist for the runtime to function:

```
bin/cmd_interpreter
bin/safety_parser
bundles/release/bin/run_infer
bundles/release/model.json
bundles/release/weights.bin
bundles/release/memory_plan.json
shared/phase7_adapter/runtime_cmd.conf
apps/safety_parser/policy.conf
```

If any required file is missing, verification fails.

### Step 5: Check Executables

The following files MUST be executable:

```
bin/cmd_interpreter
bin/safety_parser
bundles/release/bin/run_infer
```

If any binary is not executable, verification fails.

### Step 6: Write Success Status

Only if ALL previous steps pass:

1. Copy `MANIFEST.txt` to `bundles/verified/verify.manifest.txt`
2. Copy `SHA256SUMS` to `bundles/verified/verify.sha256`
3. Write `OK\n` to `bundles/verified/verify.status.txt`

## Failure Modes

| Failure | Status Content | Exit Code |
|---------|----------------|-----------|
| MANIFEST.txt missing | `FAIL:MANIFEST.txt_missing` | 1 |
| SHA256SUMS missing | `FAIL:SHA256SUMS_missing` | 1 |
| Files missing from manifest | `FAIL:missing_files_count=N` | 1 |
| Checksum mismatch | `FAIL:checksum_verification_failed` | 1 |
| Required file missing | `FAIL:required_files_missing=N` | 1 |
| Binary not executable | `FAIL:binary_not_executable=<path>` | 1 |

## Fail-Closed Behavior

The verification script is designed to fail closed:

- Any error during verification prevents `OK` from being written
- If verification is interrupted, no status file is written
- The `OK` status is only written at the very end of successful verification

## Verification Outputs

After successful verification, the following files exist:

| File | Content |
|------|---------|
| `bundles/verified/verify.status.txt` | `OK` |
| `bundles/verified/verify.log` | Verification log |
| `bundles/verified/verify.manifest.txt` | Copy of MANIFEST.txt |
| `bundles/verified/verify.sha256` | Copy of SHA256SUMS |

## Re-Verification

Verification can be re-run at any time:

```sh
./scripts/verify.sh
```

This will overwrite previous verification outputs.

## Trust Model

The verification system trusts:

1. The SHA256SUMS file at bundle creation time
2. The MANIFEST.txt file at bundle creation time
3. The sha256sum/shasum command on the host system

If you suspect bundle tampering, verify:

1. You received the bundle from a trusted source
2. The bundle checksums match your source's published checksums

## If You Received a Tarball

If you received this bundle as a tarball (`brok-clu-poc_v2-standalone.tar.gz`), follow these steps:

### Step 1: Extract the Tarball

```sh
tar -xzf brok-clu-poc_v2-standalone.tar.gz
cd brok-clu-poc_v2-standalone
```

### Step 2: Run Verification

```sh
./scripts/verify.sh
```

Verification checks the **extracted bundle contents** using `SHA256SUMS`. This is the authoritative integrity check.

### Step 3: Run Inference

After verification passes:

```sh
./scripts/run.sh examples/input_valid.txt
```

### Step 4: Run Determinism Test (Optional)

```sh
./scripts/run.sh --determinism-test examples/input_valid.txt --runs 100
```

### Important Notes

- **Never verify the tarball itself** - the tarball is a transport container only
- The hash printed by `make_tarball.sh` is for transport integrity, not bundle verification
- Authoritative verification uses `SHA256SUMS` on extracted files
- Determinism guarantees apply to extracted bundle contents, not archive bytes
- If verification fails after extraction, the tarball may have been corrupted in transit
