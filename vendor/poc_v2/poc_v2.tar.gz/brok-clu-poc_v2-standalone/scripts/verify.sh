#!/bin/sh
# verify.sh - PoC v2 Standalone Bundle Verification
#
# Validates bundle integrity via SHA256 checksums.
# Only writes OK to verification status on complete success.
# Fails closed: any error prevents verification.
#
# Exit codes:
#   0 - Verification passed
#   1 - Verification failed (integrity or file missing)
#   2 - Usage error

set -e

# Determine bundle root (script location parent)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$BUNDLE_ROOT"

# Output directories
VERIFIED_DIR="bundles/verified"
LOG_FILE="$VERIFIED_DIR/verify.log"
STATUS_FILE="$VERIFIED_DIR/verify.status.txt"
MANIFEST_OUT="$VERIFIED_DIR/verify.manifest.txt"
SHA256_OUT="$VERIFIED_DIR/verify.sha256"

# Required files for verification
MANIFEST_FILE="MANIFEST.txt"
SHA256_FILE="SHA256SUMS"

# Initialize log
init_log() {
    mkdir -p "$VERIFIED_DIR"
    rm -f "$LOG_FILE" "$STATUS_FILE" "$MANIFEST_OUT" "$SHA256_OUT"
    echo "verify_start" >> "$LOG_FILE"
    echo "bundle_root=$BUNDLE_ROOT" >> "$LOG_FILE"
}

log() {
    echo "$1" >> "$LOG_FILE"
}

fail() {
    log "verify_error=$1"
    log "verify_result=FAIL"
    echo "FAIL:$1" > "$STATUS_FILE"
    echo ""
    echo "VERIFICATION FAILED: $1"
    echo "See: $LOG_FILE"
    exit 1
}

# Step 1: Check required verification files exist
check_verification_files() {
    log "step=check_verification_files"

    if [ ! -f "$MANIFEST_FILE" ]; then
        fail "MANIFEST.txt_missing"
    fi
    log "manifest_exists=yes"

    if [ ! -f "$SHA256_FILE" ]; then
        fail "SHA256SUMS_missing"
    fi
    log "sha256sums_exists=yes"
}

# Step 2: Check all files in manifest exist
check_manifest_files() {
    log "step=check_manifest_files"

    missing_count=0
    while IFS= read -r filepath; do
        # Skip empty lines and comments
        case "$filepath" in
            ''|'#'*) continue ;;
        esac

        if [ ! -f "$filepath" ]; then
            log "missing_file=$filepath"
            missing_count=$((missing_count + 1))
        fi
    done < "$MANIFEST_FILE"

    if [ "$missing_count" -gt 0 ]; then
        fail "missing_files_count=$missing_count"
    fi

    log "all_manifest_files_present=yes"
}

# Step 3: Verify SHA256 checksums
verify_checksums() {
    log "step=verify_checksums"

    # Use shasum on macOS, sha256sum on Linux
    if command -v shasum >/dev/null 2>&1; then
        SHA_CMD="shasum -a 256"
    elif command -v sha256sum >/dev/null 2>&1; then
        SHA_CMD="sha256sum"
    else
        fail "no_sha256_command"
    fi

    checksum_errors=0
    verified_count=0

    while IFS= read -r line; do
        # Skip empty lines and comments
        case "$line" in
            ''|'#'*) continue ;;
        esac

        # Parse checksum and filename
        expected_hash=$(echo "$line" | awk '{print $1}')
        filepath=$(echo "$line" | awk '{print $2}')

        # Remove leading ./ if present
        filepath=$(echo "$filepath" | sed 's|^\./||')

        if [ ! -f "$filepath" ]; then
            log "checksum_missing_file=$filepath"
            checksum_errors=$((checksum_errors + 1))
            continue
        fi

        # Compute actual hash
        actual_hash=$($SHA_CMD "$filepath" | awk '{print $1}')

        if [ "$expected_hash" = "$actual_hash" ]; then
            log "checksum_ok=$filepath"
            verified_count=$((verified_count + 1))
        else
            log "checksum_mismatch=$filepath"
            log "expected=$expected_hash"
            log "actual=$actual_hash"
            checksum_errors=$((checksum_errors + 1))
        fi
    done < "$SHA256_FILE"

    log "verified_files=$verified_count"
    log "checksum_errors=$checksum_errors"

    if [ "$checksum_errors" -gt 0 ]; then
        fail "checksum_verification_failed"
    fi
}

# Step 4: Check required runtime files
check_runtime_files() {
    log "step=check_runtime_files"

    # Note: bin/run_infer removed - canonical runtime is bundles/release/bin/run_infer
    required_files="
bin/cmd_interpreter
bin/safety_parser
bundles/release/bin/run_infer
bundles/release/model.json
bundles/release/weights.bin
bundles/release/memory_plan.json
shared/phase7_adapter/runtime_cmd.conf
apps/safety_parser/policy.conf
"

    missing=0
    for f in $required_files; do
        if [ ! -f "$f" ]; then
            log "required_missing=$f"
            missing=$((missing + 1))
        fi
    done

    if [ "$missing" -gt 0 ]; then
        fail "required_files_missing=$missing"
    fi

    log "all_required_files_present=yes"
}

# Step 5: Check binaries are executable
check_executables() {
    log "step=check_executables"

    # Note: bin/run_infer removed - canonical runtime is bundles/release/bin/run_infer
    executables="bin/cmd_interpreter bin/safety_parser bundles/release/bin/run_infer"

    for exe in $executables; do
        if [ ! -x "$exe" ]; then
            log "not_executable=$exe"
            fail "binary_not_executable=$exe"
        fi
        log "executable_ok=$exe"
    done
}

# Step 6: Write success outputs
write_success() {
    log "step=write_success"

    # Copy manifest to verified output
    cp "$MANIFEST_FILE" "$MANIFEST_OUT"

    # Copy checksums to verified output
    cp "$SHA256_FILE" "$SHA256_OUT"

    # Write OK status
    printf 'OK\n' > "$STATUS_FILE"

    log "verify_result=OK"
    log "verify_end"
}

# Main execution
main() {
    echo "PoC v2 Standalone Bundle Verification"
    echo "======================================"
    echo ""
    echo "Bundle root: $BUNDLE_ROOT"
    echo ""

    init_log

    echo "Checking verification files..."
    check_verification_files

    echo "Checking manifest files exist..."
    check_manifest_files

    echo "Verifying SHA256 checksums..."
    verify_checksums

    echo "Checking required runtime files..."
    check_runtime_files

    echo "Checking executables..."
    check_executables

    echo "Writing verification outputs..."
    write_success

    # Count verified files from manifest
    file_count=$(grep -c -v '^\s*$' "$MANIFEST_FILE" 2>/dev/null || echo "0")

    echo ""
    echo "======================================"
    echo "VERIFICATION PASSED"
    echo ""
    echo "Files verified: $file_count"
    echo "Status: $STATUS_FILE"
    echo "Log:    $LOG_FILE"
    echo "======================================"

    exit 0
}

main
