#!/bin/sh
# relocation_test.sh - Prove bundle works when copied outside repo tree
#
# Creates a temporary copy of the bundle, runs all verification and
# execution tests, and produces evidence that relocation works.
#
# Exit codes:
#   0 - Relocation test passed
#   1 - Relocation test failed
#   2 - Setup error

set -e

# Determine bundle root (script location parent)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Create temp directory
TEMP_BASE="${TMPDIR:-/tmp}"
RELOCATED_DIR="$TEMP_BASE/brok-clu-poc_v2-relocation-test-$$"

# Output directory for evidence
EVIDENCE_DIR="artifacts/relocation_test"
REPORT_FILE="$EVIDENCE_DIR/relocation_report.txt"

cleanup() {
    if [ -d "$RELOCATED_DIR" ]; then
        rm -rf "$RELOCATED_DIR"
    fi
}

trap cleanup EXIT

fail() {
    echo "RELOCATION TEST FAILED: $1"
    exit 1
}

log_report() {
    echo "$1" >> "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR/relocation_report.txt"
}

main() {
    echo "PoC v2 Standalone - Relocation Test"
    echo "===================================="
    echo ""
    echo "Source bundle: $BUNDLE_ROOT"
    echo "Temp location: $RELOCATED_DIR"
    echo ""

    # Step 1: Create temp directory and copy bundle
    echo "Step 1: Copying bundle to temp location..."
    mkdir -p "$RELOCATED_DIR"

    # Copy bundle excluding artifacts/ to avoid misleading evidence
    rsync -a --exclude='artifacts/' --exclude='bundles/verified/' "$BUNDLE_ROOT/" "$RELOCATED_DIR/brok-clu-poc_v2-standalone/"

    if [ ! -d "$RELOCATED_DIR/brok-clu-poc_v2-standalone" ]; then
        fail "Failed to copy bundle"
    fi

    # Create evidence directory in relocated copy
    mkdir -p "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR"

    # Start report
    {
        echo "relocation_test_report"
        echo "source_bundle=$BUNDLE_ROOT"
        echo "relocated_to=$RELOCATED_DIR/brok-clu-poc_v2-standalone"
        echo ""
    } > "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR/relocation_report.txt"

    # Change to relocated bundle
    cd "$RELOCATED_DIR/brok-clu-poc_v2-standalone"

    # Step 2: Run verification
    echo "Step 2: Running verification in relocated bundle..."
    log_report "step=verification"

    if ./scripts/verify.sh > "$EVIDENCE_DIR/verify_output.txt" 2>&1; then
        log_report "verify_result=PASS"
        log_report "verify_exit_code=0"
        echo "  Verification: PASS"
    else
        verify_exit=$?
        log_report "verify_result=FAIL"
        log_report "verify_exit_code=$verify_exit"
        echo "  Verification: FAIL (exit $verify_exit)"
        log_report "test_verdict=FAIL"
        log_report "failure_reason=verification_failed"
        fail "Verification failed in relocated bundle"
    fi

    # Step 3: Run with valid input
    echo "Step 3: Running with valid input..."
    log_report "step=run_valid"

    if ./scripts/run.sh examples/input_valid.txt > "$EVIDENCE_DIR/run_valid_output.txt" 2>&1; then
        log_report "run_valid_result=PASS"
        log_report "run_valid_exit_code=0"
        echo "  Valid input run: PASS"
    else
        run_exit=$?
        log_report "run_valid_result=FAIL"
        log_report "run_valid_exit_code=$run_exit"
        echo "  Valid input run: FAIL (exit $run_exit)"
        log_report "test_verdict=FAIL"
        log_report "failure_reason=run_valid_failed"
        fail "Valid input run failed in relocated bundle"
    fi

    # Step 4: Run with invalid input
    echo "Step 4: Running with invalid input..."
    log_report "step=run_invalid"

    if ./scripts/run.sh examples/input_invalid.txt > "$EVIDENCE_DIR/run_invalid_output.txt" 2>&1; then
        log_report "run_invalid_result=PASS"
        log_report "run_invalid_exit_code=0"
        echo "  Invalid input run: PASS"
    else
        run_exit=$?
        log_report "run_invalid_result=FAIL"
        log_report "run_invalid_exit_code=$run_exit"
        echo "  Invalid input run: FAIL (exit $run_exit)"
        log_report "test_verdict=FAIL"
        log_report "failure_reason=run_invalid_failed"
        fail "Invalid input run failed in relocated bundle"
    fi

    # Step 5: Run determinism test
    echo "Step 5: Running determinism test (100 runs)..."
    log_report "step=determinism_test"

    if ./scripts/run.sh --determinism-test examples/input_valid.txt --runs 100 > "$EVIDENCE_DIR/determinism_output.txt" 2>&1; then
        log_report "determinism_result=PASS"
        log_report "determinism_exit_code=0"
        echo "  Determinism test: PASS"
    else
        det_exit=$?
        log_report "determinism_result=FAIL"
        log_report "determinism_exit_code=$det_exit"
        echo "  Determinism test: FAIL (exit $det_exit)"
        log_report "test_verdict=FAIL"
        log_report "failure_reason=determinism_failed"
        fail "Determinism test failed in relocated bundle"
    fi

    # Step 6: Record success
    log_report ""
    log_report "test_verdict=PASS"
    log_report "all_tests_passed=yes"

    echo ""
    echo "===================================="
    echo "RELOCATION TEST PASSED"
    echo ""
    echo "All tests passed in relocated bundle at:"
    echo "  $RELOCATED_DIR/brok-clu-poc_v2-standalone"
    echo ""

    # Step 7: Copy evidence back to original bundle
    echo "Copying evidence back to original bundle..."
    mkdir -p "$BUNDLE_ROOT/$EVIDENCE_DIR"
    cp "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR/relocation_report.txt" "$BUNDLE_ROOT/$EVIDENCE_DIR/"
    cp "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR/verify_output.txt" "$BUNDLE_ROOT/$EVIDENCE_DIR/"
    cp "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR/run_valid_output.txt" "$BUNDLE_ROOT/$EVIDENCE_DIR/"
    cp "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR/run_invalid_output.txt" "$BUNDLE_ROOT/$EVIDENCE_DIR/"
    cp "$RELOCATED_DIR/brok-clu-poc_v2-standalone/$EVIDENCE_DIR/determinism_output.txt" "$BUNDLE_ROOT/$EVIDENCE_DIR/"

    echo ""
    echo "Evidence written to:"
    echo "  $BUNDLE_ROOT/$EVIDENCE_DIR/relocation_report.txt"
    echo "===================================="

    exit 0
}

main
