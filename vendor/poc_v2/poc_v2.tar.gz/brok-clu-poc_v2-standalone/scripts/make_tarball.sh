#!/bin/sh
# make_tarball.sh - Create optional tarball distribution wrapper for PoC v2
#
# IMPORTANT: The tarball is a TRANSPORT CONVENIENCE only.
# The directory remains the canonical/authoritative artifact.
# Verification must occur AFTER extraction, never on the tarball itself.
#
# Exit codes:
#   0 - Tarball created successfully
#   1 - Error during creation
#   2 - Usage error

set -e

# Determine bundle root
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BUNDLE_NAME="brok-clu-poc_v2-standalone"

cd "$BUNDLE_ROOT"

# Output location
DIST_DIR="dist"
TARBALL_NAME="${BUNDLE_NAME}.tar.gz"
TARBALL_PATH="${DIST_DIR}/${TARBALL_NAME}"

echo "PoC v2 Standalone - Tarball Packaging"
echo "======================================"
echo ""
echo "Bundle root: $BUNDLE_ROOT"
echo "Output:      $TARBALL_PATH"
echo ""

# Create dist directory if needed
mkdir -p "$DIST_DIR"

# Build list of files to include (from MANIFEST.txt plus documentation)
# We include all shipped files but exclude:
# - dist/ (output directory)
# - artifacts/ (generated run outputs)
# - bundles/verified/ (generated verification outputs)

echo "Collecting files for tarball..."

# Check if GNU tar is available (for reproducible options)
TAR_CMD="tar"
TAR_OPTS=""
WARNINGS=""

# Test for GNU tar options
if tar --version 2>/dev/null | grep -q "GNU"; then
    TAR_TYPE="GNU"
    TAR_OPTS="--sort=name --mtime=@0 --owner=0 --group=0 --numeric-owner"
elif tar --help 2>&1 | grep -q "bsdtar"; then
    TAR_TYPE="BSD"
    # BSD tar on macOS doesn't support --sort, --mtime=@0
    # Use COPYFILE_DISABLE to exclude AppleDouble
    export COPYFILE_DISABLE=1
    WARNINGS="WARNING: BSD tar detected. Tarball may not be byte-reproducible across builds."
else
    TAR_TYPE="unknown"
    WARNINGS="WARNING: Unknown tar implementation. Tarball may not be byte-reproducible."
fi

echo "Tar type: $TAR_TYPE"
if [ -n "$WARNINGS" ]; then
    echo "$WARNINGS"
fi
echo ""

# Files to include (authoritative bundle content)
# Using MANIFEST.txt as base, plus MANIFEST.txt and SHA256SUMS themselves
INCLUDE_FILES="
MANIFEST.txt
SHA256SUMS
$(cat MANIFEST.txt)
"

# Create a temporary file list
TMPLIST=$(mktemp)
trap "rm -f $TMPLIST" EXIT

# Write sorted, unique file list
echo "$INCLUDE_FILES" | tr ' ' '\n' | grep -v '^$' | sort -u | while read -r f; do
    # Strip leading ./
    f_clean=$(echo "$f" | sed 's|^\./||')
    if [ -f "$f_clean" ]; then
        echo "$f_clean"
    fi
done > "$TMPLIST"

FILE_COUNT=$(wc -l < "$TMPLIST" | tr -d ' ')
echo "Files to package: $FILE_COUNT"
echo ""

# Create tarball
echo "Creating tarball..."

# Remove existing tarball if present
rm -f "$TARBALL_PATH"

# Create tarball with directory prefix by working from parent directory
# This ensures the tarball extracts to brok-clu-poc_v2-standalone/
PARENT_DIR="$(cd "$BUNDLE_ROOT/.." && pwd)"
TARBALL_ABS="$BUNDLE_ROOT/$TARBALL_PATH"

# Prefix all files with the bundle name
TMPLIST_PREFIXED=$(mktemp)
sed "s|^|$BUNDLE_NAME/|" "$TMPLIST" > "$TMPLIST_PREFIXED"

cd "$PARENT_DIR"

if [ "$TAR_TYPE" = "GNU" ]; then
    # GNU tar with reproducible options
    tar $TAR_OPTS \
        --exclude='.DS_Store' \
        --exclude='._*' \
        --exclude='*/dist' \
        --exclude='*/artifacts' \
        --exclude='*/bundles/verified' \
        --exclude='*/bundles/release/evidence' \
        -czf "$TARBALL_ABS" \
        -T "$TMPLIST_PREFIXED"
else
    # BSD tar or fallback
    tar \
        --exclude='.DS_Store' \
        --exclude='._*' \
        --exclude='*/dist' \
        --exclude='*/artifacts' \
        --exclude='*/bundles/verified' \
        --exclude='*/bundles/release/evidence' \
        -czf "$TARBALL_ABS" \
        -T "$TMPLIST_PREFIXED"
fi

rm -f "$TMPLIST_PREFIXED"
cd "$BUNDLE_ROOT"

if [ ! -f "$TARBALL_PATH" ]; then
    echo "ERROR: Failed to create tarball"
    exit 1
fi

# Calculate size and hash
TARBALL_SIZE=$(ls -l "$TARBALL_PATH" | awk '{print $5}')
TARBALL_SIZE_HUMAN=$(ls -lh "$TARBALL_PATH" | awk '{print $5}')

# Calculate SHA256
if command -v shasum >/dev/null 2>&1; then
    TARBALL_SHA256=$(shasum -a 256 "$TARBALL_PATH" | awk '{print $1}')
elif command -v sha256sum >/dev/null 2>&1; then
    TARBALL_SHA256=$(sha256sum "$TARBALL_PATH" | awk '{print $1}')
else
    TARBALL_SHA256="(sha256 command not available)"
fi

echo ""
echo "======================================"
echo "Tarball created successfully"
echo ""
echo "Path:   $TARBALL_PATH"
echo "Size:   $TARBALL_SIZE bytes ($TARBALL_SIZE_HUMAN)"
echo ""
echo "Transport hash (non-authoritative):"
echo "  SHA256: $TARBALL_SHA256"
echo ""
echo "IMPORTANT: This hash is for transport integrity only."
echo "           Authoritative verification uses SHA256SUMS"
echo "           on extracted bundle contents."
echo "======================================"
echo ""
echo "To use this tarball:"
echo "  1. Extract:  tar -xzf $TARBALL_NAME"
echo "  2. Enter:    cd $BUNDLE_NAME"
echo "  3. Verify:   ./scripts/verify.sh"
echo "  4. Run:      ./scripts/run.sh examples/input_valid.txt"

exit 0
