#!/bin/sh
# run.sh - PoC v2 Standalone Bundle Runner
#
# Executes cmd_interpreter or safety_parser with verification gating.
# Requires prior successful verification.
#
# Usage:
#   ./scripts/run.sh <input_file>
#   ./scripts/run.sh --safety <input_file>
#   ./scripts/run.sh --determinism-test <input_file> --runs N
#
# Exit codes:
#   0 - Success (or determinism test PASS, or safety ACCEPT)
#   1 - Verification required
#   2 - Usage error
#   3 - File not found
#   10+ - Application exit codes (passed through)
#   20 - Safety REJECT

set -e

# Determine bundle root
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

cd "$BUNDLE_ROOT"

# Paths
VERIFIED_STATUS="bundles/verified/verify.status.txt"
CMD_INTERPRETER="bin/cmd_interpreter"
SAFETY_PARSER="bin/safety_parser"
RUNS_DIR="artifacts/runs"
SAFETY_DIR="artifacts/safety"
DETERMINISM_DIR="artifacts/determinism"

# Print usage
usage() {
    echo "Usage:"
    echo "  $0 <input_file>                              Run cmd_interpreter"
    echo "  $0 --safety <input_file>                     Run safety_parser"
    echo "  $0 --determinism-test <input_file> --runs N  Run determinism test"
    echo ""
    echo "Options:"
    echo "  --safety             Run safety_parser instead of cmd_interpreter"
    echo "  --determinism-test   Run determinism verification"
    echo "  --runs N             Number of runs for determinism test (default: 100)"
    exit 2
}

# Check verification status
check_verification() {
    if [ ! -f "$VERIFIED_STATUS" ]; then
        echo "ERROR: Verification required"
        echo ""
        echo "Run verification first:"
        echo "  ./scripts/verify.sh"
        exit 1
    fi

    status=$(cat "$VERIFIED_STATUS" | tr -d '[:space:]')
    if [ "$status" != "OK" ]; then
        echo "ERROR: Verification status is not OK"
        echo "Status: $status"
        echo ""
        echo "Re-run verification:"
        echo "  ./scripts/verify.sh"
        exit 1
    fi
}

# Generate run ID (sequential, deterministic)
get_next_run_id() {
    base_dir="$1"
    mkdir -p "$base_dir"

    # Find highest existing run number
    highest=0
    for dir in "$base_dir"/run_*; do
        if [ -d "$dir" ]; then
            num=$(basename "$dir" | sed 's/run_//')
            if [ "$num" -gt "$highest" ] 2>/dev/null; then
                highest=$num
            fi
        fi
    done

    echo $((highest + 1))
}

# Format run ID with padding
format_run_id() {
    printf "run_%03d" "$1"
}

# Execute single run
single_run() {
    input_file="$1"
    output_dir="$2"

    mkdir -p "$output_dir"

    # Copy input
    cp "$input_file" "$output_dir/input.txt"

    # Run cmd_interpreter
    set +e
    "$CMD_INTERPRETER" --input "$output_dir/input.txt" > "$output_dir/stdout.raw.kv" 2> "$output_dir/stderr.txt"
    exit_code=$?
    set -e

    # Record exit code
    echo "$exit_code" > "$output_dir/exit_code.txt"

    # Create derived JSON (clearly labeled)
    create_derived_json "$output_dir/stdout.raw.kv" "$output_dir/output.derived.json"

    return $exit_code
}

# Create derived JSON from key=value output
create_derived_json() {
    kv_file="$1"
    json_file="$2"

    # Start JSON object
    printf '{\n' > "$json_file"
    printf '  "_derived": true,\n' >> "$json_file"
    printf '  "_source": "stdout.raw.kv",\n' >> "$json_file"

    # Parse key=value pairs
    first=1
    while IFS='=' read -r key value; do
        [ -z "$key" ] && continue

        if [ $first -eq 0 ]; then
            printf ',\n' >> "$json_file"
        fi
        first=0

        # Escape value for JSON
        escaped_value=$(echo "$value" | sed 's/\\/\\\\/g; s/"/\\"/g')
        printf '  "%s": "%s"' "$key" "$escaped_value" >> "$json_file"
    done < "$kv_file"

    printf '\n}\n' >> "$json_file"
}

# Standard run mode (cmd_interpreter)
run_standard() {
    input_file="$1"

    if [ ! -f "$input_file" ]; then
        echo "ERROR: Input file not found: $input_file"
        exit 3
    fi

    run_num=$(get_next_run_id "$RUNS_DIR")
    run_id=$(format_run_id "$run_num")
    output_dir="$RUNS_DIR/$run_id"

    echo "PoC v2 Standalone - Run Mode (cmd_interpreter)"
    echo "==============================================="
    echo ""
    echo "Input:  $input_file"
    echo "Output: $output_dir"
    echo ""

    single_run "$input_file" "$output_dir"
    exit_code=$?

    echo "Run complete."
    echo ""
    echo "Artifacts:"
    echo "  $output_dir/input.txt"
    echo "  $output_dir/stdout.raw.kv"
    echo "  $output_dir/stderr.txt"
    echo "  $output_dir/exit_code.txt"
    echo "  $output_dir/output.derived.json"
    echo ""
    echo "Exit code: $exit_code"
    echo "==============================================="

    # Show authoritative output
    echo ""
    echo "Authoritative output (key=value):"
    cat "$output_dir/stdout.raw.kv"

    exit $exit_code
}

# Safety parser run mode
run_safety() {
    input_file="$1"

    if [ ! -f "$input_file" ]; then
        echo "ERROR: Input file not found: $input_file"
        exit 3
    fi

    run_num=$(get_next_run_id "$SAFETY_DIR")
    run_id=$(format_run_id "$run_num")
    output_dir="$SAFETY_DIR/$run_id"

    mkdir -p "$output_dir"

    echo "PoC v2 Standalone - Safety Parser Mode"
    echo "======================================="
    echo ""
    echo "Input:  $input_file"
    echo "Output: $output_dir"
    echo ""

    # Copy input
    cp "$input_file" "$output_dir/input.txt"

    # Run safety_parser
    set +e
    "$SAFETY_PARSER" --input "$output_dir/input.txt" > "$output_dir/stdout.raw.kv" 2> "$output_dir/stderr.txt"
    exit_code=$?
    set -e

    # Record exit code
    echo "$exit_code" > "$output_dir/exit_code.txt"

    # Create derived JSON
    create_derived_json "$output_dir/stdout.raw.kv" "$output_dir/output.derived.json"

    echo "Run complete."
    echo ""
    echo "Artifacts:"
    echo "  $output_dir/input.txt"
    echo "  $output_dir/stdout.raw.kv"
    echo "  $output_dir/stderr.txt"
    echo "  $output_dir/exit_code.txt"
    echo "  $output_dir/output.derived.json"
    echo ""
    echo "Exit code: $exit_code"
    echo "======================================="

    # Show authoritative output
    echo ""
    echo "Authoritative output (key=value):"
    cat "$output_dir/stdout.raw.kv"

    # Interpret decision
    echo ""
    if grep -q "^decision=ACCEPT" "$output_dir/stdout.raw.kv" 2>/dev/null; then
        echo "Decision: ACCEPT (exit 0)"
    elif grep -q "^decision=REJECT" "$output_dir/stdout.raw.kv" 2>/dev/null; then
        echo "Decision: REJECT (exit 20)"
    else
        echo "Decision: (see exit code)"
    fi

    exit $exit_code
}

# Determinism test mode
run_determinism_test() {
    input_file="$1"
    num_runs="$2"

    if [ ! -f "$input_file" ]; then
        echo "ERROR: Input file not found: $input_file"
        exit 3
    fi

    if [ "$num_runs" -lt 2 ]; then
        echo "ERROR: --runs must be at least 2"
        exit 2
    fi

    echo "PoC v2 Standalone - Determinism Test"
    echo "====================================="
    echo ""
    echo "Input:  $input_file"
    echo "Runs:   $num_runs"
    echo ""

    # Create determinism test directory
    test_dir="$DETERMINISM_DIR/runs"
    mkdir -p "$test_dir"

    # Clear previous determinism test runs
    rm -rf "$test_dir"/run_*

    # Run baseline
    echo "Running baseline (run 1 of $num_runs)..."
    baseline_dir="$test_dir/run_001"
    single_run "$input_file" "$baseline_dir"
    baseline_exit=$?

    # Subsequent runs
    failures=0
    for i in $(seq 2 $num_runs); do
        run_id=$(format_run_id "$i")
        run_dir="$test_dir/$run_id"

        printf "Running %s of %d..." "$run_id" "$num_runs"

        single_run "$input_file" "$run_dir"
        run_exit=$?

        # Compare to baseline
        if [ "$run_exit" -ne "$baseline_exit" ]; then
            echo " EXIT_CODE_MISMATCH"
            failures=$((failures + 1))
            continue
        fi

        # Compare stdout byte-for-byte
        if ! diff -q "$baseline_dir/stdout.raw.kv" "$run_dir/stdout.raw.kv" >/dev/null 2>&1; then
            echo " STDOUT_MISMATCH"
            failures=$((failures + 1))
            continue
        fi

        echo " OK"
    done

    # Write report
    report_file="$DETERMINISM_DIR/report.txt"
    {
        echo "determinism_test_result"
        echo "input_file=$input_file"
        echo "total_runs=$num_runs"
        echo "failures=$failures"
        if [ "$failures" -eq 0 ]; then
            echo "verdict=PASS"
        else
            echo "verdict=FAIL"
        fi
    } > "$report_file"

    echo ""
    echo "====================================="
    echo "Determinism Test Complete"
    echo ""
    echo "Total runs: $num_runs"
    echo "Failures:   $failures"
    echo ""

    if [ "$failures" -eq 0 ]; then
        echo "VERDICT: PASS"
        echo ""
        echo "All $num_runs runs produced byte-identical output."
        echo "Report: $report_file"
        exit 0
    else
        echo "VERDICT: FAIL"
        echo ""
        echo "Detected $failures non-deterministic runs."
        echo "Report: $report_file"
        exit 1
    fi
}

# Parse arguments
main() {
    if [ $# -lt 1 ]; then
        usage
    fi

    # Check verification first
    check_verification

    # Parse mode
    case "$1" in
        --safety)
            shift
            if [ $# -lt 1 ]; then
                usage
            fi
            run_safety "$1"
            ;;
        --determinism-test)
            shift
            if [ $# -lt 1 ]; then
                usage
            fi
            input_file="$1"
            shift

            num_runs=100  # default
            while [ $# -gt 0 ]; do
                case "$1" in
                    --runs)
                        shift
                        if [ $# -lt 1 ]; then
                            usage
                        fi
                        num_runs="$1"
                        shift
                        ;;
                    *)
                        usage
                        ;;
                esac
            done

            run_determinism_test "$input_file" "$num_runs"
            ;;
        --help|-h)
            usage
            ;;
        *)
            if [ $# -ne 1 ]; then
                usage
            fi
            run_standard "$1"
            ;;
    esac
}

main "$@"
