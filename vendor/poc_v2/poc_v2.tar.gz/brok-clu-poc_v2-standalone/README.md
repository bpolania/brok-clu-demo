# Brok-CLU PoC v2 Standalone Demo Bundle

A self-contained, relocatable demonstration bundle for Brok-CLU Command Language Understanding.

## What This Bundle Is

This bundle provides:

- Pre-built cmd_interpreter and safety_parser binaries (macOS arm64)
- Pre-built run_infer runtime binary
- Model weights and configuration
- Verification and execution scripts
- Example inputs for demonstration

## What This Bundle Is Not

This bundle is NOT:

- A library or SDK
- A configurable runtime
- A production deployment artifact
- A replacement for full Brok-CLU repo

This is a demonstration bundle showing deterministic CLU inference with verification-first semantics.

## Quick Start

```sh
# 1. Verify bundle integrity
./scripts/verify.sh

# 2. Run with valid input (cmd_interpreter)
./scripts/run.sh examples/input_valid.txt

# 3. Run with invalid input (cmd_interpreter)
./scripts/run.sh examples/input_invalid.txt

# 4. Run safety parser
./scripts/run.sh --safety examples/input_valid.txt

# 5. Run determinism test (100 runs)
./scripts/run.sh --determinism-test examples/input_valid.txt --runs 100

# 6. Run relocation test (proves bundle works when copied elsewhere)
./scripts/relocation_test.sh
```

## Relocatability

This bundle is designed to work when copied or extracted anywhere on the filesystem.
The relocation test (`scripts/relocation_test.sh`) proves this by:

1. Copying the bundle to a temporary directory outside the repo tree
2. Running all verification and execution tests in the copied location
3. Producing evidence that all tests pass

Run `./scripts/relocation_test.sh` to verify relocatability and generate evidence.

## Distribution

### Canonical Artifact

**The directory is the canonical distribution artifact.** All verification, determinism guarantees, and integrity checks apply to the extracted bundle contents.

### Optional Tarball

An optional tarball can be created for transport convenience:

```sh
./scripts/make_tarball.sh
```

This produces `dist/brok-clu-poc_v2-standalone.tar.gz`.

**Important:**
- The tarball is a transport container only, NOT an authoritative artifact
- Never attempt to "verify the tarball" - verification applies to extracted contents
- Determinism guarantees apply to bundle contents, not archive bytes
- The tarball hash printed by `make_tarball.sh` is for transport integrity only

### Using a Tarball

If you received this bundle as a tarball:

```sh
# 1. Extract
tar -xzf brok-clu-poc_v2-standalone.tar.gz

# 2. Enter the extracted directory
cd brok-clu-poc_v2-standalone

# 3. Verify bundle integrity (MANDATORY)
./scripts/verify.sh

# 4. Run inference
./scripts/run.sh examples/input_valid.txt
```

## Output Contract

**Authoritative output is key=value format from stdout.**

The `stdout.raw.kv` file contains the authoritative output:

```
status=OK
intent_id=14
n_slots=0
dispatch=unknown
```

The `output.derived.json` file is a convenience transformation clearly labeled as derived. It is NOT authoritative.

## Expected Behavior for Valid vs Invalid Examples

### Valid Input (`examples/input_valid.txt`)

Content: `turn on the lights`

Expected output keys:
- `status=OK` - Inference succeeded
- `intent_id=<N>` - Predicted intent ID (integer)
- `n_slots=<N>` - Number of extracted slots
- `dispatch=<action>` - Dispatch action (may be "unknown" for unmapped intents)

Exit code: 0

### Invalid Input (`examples/input_invalid.txt`)

Content: `invalid command format`

**Note:** "Invalid" in this context does NOT mean the input is rejected. The model performs inference on any text input. The term "invalid" indicates the input is semantically unclear or unlikely to produce a meaningful intent mapping.

Expected output keys:
- `status=OK` - Inference still succeeds (model processes any input)
- `intent_id=<N>` - Predicted intent ID (may be unexpected)
- `n_slots=<N>` - Number of extracted slots
- `dispatch=<action>` - Dispatch action (typically "unknown")

Exit code: 0

### When Does the Model Reject Input?

The cmd_interpreter returns non-OK status only for:
- Empty input after normalization (`status=INVALID_INPUT`, exit 11)
- Input exceeding maximum length (`status=INVALID_INPUT`, exit 11)
- Verification not performed (`status=VERIFY_REQUIRED`, exit 10)
- Runtime errors (`status=RUNTIME_ERROR`, exit 13)

The safety_parser can return REJECT based on policy rules:
- Intent not in allowlist (`decision=REJECT reason=intent_not_allowed`, exit 20)
- Slot key matches deny rule (`decision=REJECT reason=denied_slot_key`, exit 20)

### Invalid Input vs Rejected Input (Summary)

| Term | Meaning | status | Exit Code |
|------|---------|--------|-----------|
| **Invalid input** | Semantically unclear or low-confidence text | `OK` | 0 |
| **Rejected input** | Fails validation or runtime checks | non-OK | non-zero |

**Key distinction:** "Invalid" is a semantic label for demonstration purposes. The model still performs inference and returns `status=OK`. True rejection only occurs for structural failures (empty input, length exceeded, verification missing, runtime error) and is signaled by `status != OK` and a non-zero exit code.

## Safety Parser Mode

The safety_parser applies policy rules to inference results. Run with:

```sh
./scripts/run.sh --safety examples/input_valid.txt
```

Output includes:
- `decision=ACCEPT` or `decision=REJECT`
- `reason=<reason_code>`
- Standard inference fields (status, intent_id, n_slots)

Exit codes:
- 0: ACCEPT (policy satisfied)
- 20: REJECT (policy violation)

## Directory Structure

```
brok-clu-poc_v2-standalone/
  bin/                          Application binaries
    cmd_interpreter             Command interpreter
    safety_parser               Safety parser
  bundles/
    release/                    Runtime bundle
      bin/run_infer             Runtime binary (canonical location)
      model.json                Model configuration
      weights.bin               Model weights
      memory_plan.json          Memory allocation plan
    verified/                   Verification outputs (generated)
  shared/
    phase7_adapter/
      runtime_cmd.conf          Runtime command configuration
  apps/
    safety_parser/
      policy.conf               Safety parser policy
  examples/
    input_valid.txt             Example valid input
    input_invalid.txt           Example invalid input
  scripts/
    verify.sh                   Bundle verification script
    run.sh                      Execution script
    relocation_test.sh          Relocation test script
    make_tarball.sh             Optional tarball packaging script
  dist/                         Tarball output directory (generated)
  artifacts/
    runs/                       cmd_interpreter outputs (generated)
    safety/                     safety_parser outputs (generated)
    determinism/                Determinism test outputs (generated)
    relocation_test/            Relocation test evidence (generated)
  MANIFEST.txt                  File manifest (all shipped files)
  SHA256SUMS                    SHA256 checksums (all shipped files)
  VERSION.txt                   Bundle version info
  README.md                     This file
  VERIFY.md                     Verification semantics
  EVIDENCE_MAP.md               Evidence pointers
  FREEZE_ATTESTATION.md         Freeze attestation
```

## Runtime Binary Location

The canonical runtime binary is located at:
```
bundles/release/bin/run_infer
```

This path is referenced in `shared/phase7_adapter/runtime_cmd.conf`. There is only one copy of the runtime binary in the bundle to avoid ambiguity.

## Verification

Verification is MANDATORY before execution. See VERIFY.md for detailed semantics.

```sh
./scripts/verify.sh
```

Verification (full-bundle coverage):

1. Checks all 18 files in MANIFEST.txt exist
2. Validates SHA256 checksums from SHA256SUMS for all files
3. Checks required runtime files are present and accessible
4. Checks binaries are executable
5. Writes `OK` to `bundles/verified/verify.status.txt` only on success

## Execution

After successful verification:

```sh
# cmd_interpreter (default)
./scripts/run.sh <input_file>

# safety_parser
./scripts/run.sh --safety <input_file>

# Determinism test
./scripts/run.sh --determinism-test <input_file> --runs N
```

### Run Outputs

Each run creates artifacts in the appropriate directory:

**cmd_interpreter:** `artifacts/runs/run_XXX/`
**safety_parser:** `artifacts/safety/run_XXX/`
**determinism:** `artifacts/determinism/runs/run_XXX/`

| File | Description |
|------|-------------|
| input.txt | Input file copy |
| stdout.raw.kv | Authoritative key=value output |
| stderr.txt | Standard error |
| exit_code.txt | Exit code |
| output.derived.json | Derived JSON (NOT authoritative) |

### Determinism Test

The determinism test runs inference N times and compares outputs:

- Creates `artifacts/determinism/runs/run_XXX/` for each run
- Compares all runs to baseline (run_001)
- Writes `artifacts/determinism/report.txt` with verdict
- Exits 0 on PASS, non-zero on FAIL

## Exit Codes

### verify.sh

| Code | Meaning |
|------|---------|
| 0 | Verification passed |
| 1 | Verification failed |
| 2 | Usage error |

### run.sh

| Code | Meaning |
|------|---------|
| 0 | Success (or determinism PASS, or safety ACCEPT) |
| 1 | Verification required |
| 2 | Usage error |
| 3 | Input file not found |
| 10 | VERIFY_REQUIRED |
| 11 | INVALID_INPUT |
| 12 | RUNTIME_REJECT |
| 13 | RUNTIME_ERROR |
| 14 | INTERNAL_ERROR |
| 20 | Safety REJECT |

### relocation_test.sh

| Code | Meaning |
|------|---------|
| 0 | Relocation test passed |
| 1 | Relocation test failed |
| 2 | Setup error |

## Sanity Check

Minimal commands to validate the bundle:

```sh
# From bundle root (brok-clu-poc_v2-standalone/)

# 1. Verify integrity
./scripts/verify.sh

# 2. Run valid input
./scripts/run.sh examples/input_valid.txt

# 3. Run determinism test
./scripts/run.sh --determinism-test examples/input_valid.txt --runs 10
```

To build and test a tarball:

```sh
# Build tarball
./scripts/make_tarball.sh

# Extract to temp location
mkdir -p /tmp/test-bundle
tar -xzf dist/brok-clu-poc_v2-standalone.tar.gz -C /tmp/test-bundle

# Verify and run in extracted location
cd /tmp/test-bundle/brok-clu-poc_v2-standalone
./scripts/verify.sh
./scripts/run.sh examples/input_valid.txt
```

## Platform

This bundle is built for:

- Platform: macOS
- Architecture: arm64

## License

MIT
