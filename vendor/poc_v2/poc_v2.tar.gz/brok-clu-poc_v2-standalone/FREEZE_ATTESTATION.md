# Freeze Attestation

## PoC v2 Standalone Bundle

This bundle is frozen and represents the complete PoC v2 standalone demo artifact.

## Attestation Statements

### 1. Bundle Status

The PoC v2 standalone bundle is:

- **FROZEN**: No further modifications will be made
- **COMPLETE**: Contains all required components for demonstration
- **SELF-CONTAINED**: Can be extracted and run without external dependencies
- **RELOCATABLE**: Proven to work when copied outside the repo tree

### 2. PoC v1 Immutability

PoC v1 artifacts were used as immutable input:

- No PoC v1 code was modified
- No PoC v1 binaries were modified
- No PoC v1 configurations were modified
- No PoC v1 semantics were changed

The binaries `cmd_interpreter` and `safety_parser` are byte-identical copies from:
`dist/poc_v1/bin/macos-arm64/`

### 3. Verification Semantics

The verification-first semantics are preserved:

- Bundle requires verification before execution
- run.sh refuses to run without prior verification
- Verification checks file integrity via SHA256
- Only successful verification writes `OK` status
- Full-bundle verification covers 18 shipped files

### 4. Determinism

Determinism properties are preserved:

- Same input produces same output across runs
- No timestamps in outputs
- No host/user identifiers in outputs
- No random values in outputs
- 100-run determinism test produces PASS

### 5. Output Contract

The authoritative output contract is preserved:

- Key=value format from stdout is authoritative
- JSON derived output is clearly labeled as non-authoritative
- Exit codes follow PoC v1 semantics

### 6. Runtime Binary Location

There is exactly ONE runtime binary in the bundle:
- Location: `bundles/release/bin/run_infer`
- Referenced by: `shared/phase7_adapter/runtime_cmd.conf`
- No duplicate copies exist

### 7. Relocation Proof

The bundle has been proven relocatable:

- `scripts/relocation_test.sh` copies bundle to temp directory
- All verification and execution tests pass in relocated location
- Evidence recorded in `artifacts/relocation_test/relocation_report.txt`

## Evidence References

| Evidence Type | Path |
|---------------|------|
| Verification status | `bundles/verified/verify.status.txt` |
| Verification log | `bundles/verified/verify.log` |
| Valid input run | `artifacts/runs/run_001/stdout.raw.kv` |
| Invalid input run | `artifacts/runs/run_002/stdout.raw.kv` |
| Safety parser run | `artifacts/safety/run_001/stdout.raw.kv` |
| Determinism report | `artifacts/determinism/report.txt` |
| Relocation report | `artifacts/relocation_test/relocation_report.txt` |

## Reproduction Instructions

To reproduce this bundle from the Brok-CLU repository:

```sh
# From repository root (Brok-CLU/)

# 1. Build run_infer with dispatch sources
cd runtime
clang -Wall -Wextra -O2 -I./include -I../generated -o bin/run_infer \
  src/clu_runtime.c src/brok_quant.c src/brok_kernels.c src/brok_bucket.c \
  src/brok_template_exec.c src/brok_dispatch.c src/brok_profile.c \
  src/brok_grammar_runtime.c ../generated/brok_grammar_tables.c \
  src/brok_schema_tokens.c src/brok_hashes.c src/run_infer.c -lm
cd ..

# 2. Create bundle directory structure
mkdir -p brok-clu-poc_v2-standalone/{bin,apps/safety_parser,shared/phase7_adapter}
mkdir -p brok-clu-poc_v2-standalone/{bundles/verified,bundles/release/bin}
mkdir -p brok-clu-poc_v2-standalone/{examples,scripts}
mkdir -p brok-clu-poc_v2-standalone/artifacts/{runs,safety,determinism/runs,relocation_test}

# 3. Copy binaries (only runtime goes to bundles/release/bin/)
cp dist/poc_v1/bin/macos-arm64/cmd_interpreter brok-clu-poc_v2-standalone/bin/
cp dist/poc_v1/bin/macos-arm64/safety_parser brok-clu-poc_v2-standalone/bin/
cp runtime/bin/run_infer brok-clu-poc_v2-standalone/bundles/release/bin/

# 4. Copy model files
cp model/export/runtime/runtime_model.json brok-clu-poc_v2-standalone/bundles/release/model.json
cp model/export/runtime/weights.bin brok-clu-poc_v2-standalone/bundles/release/weights.bin
cp model/export/runtime/memory_plan.json brok-clu-poc_v2-standalone/bundles/release/memory_plan.json

# 5. Copy configuration
cp apps/safety_parser/policy.conf brok-clu-poc_v2-standalone/apps/safety_parser/

# 6. Create runtime_cmd.conf
echo "bundles/release/bin/run_infer bundles/release/model.json bundles/release/weights.bin bundles/release/memory_plan.json" > brok-clu-poc_v2-standalone/shared/phase7_adapter/runtime_cmd.conf

# 7. Create example inputs
echo "turn on the lights" > brok-clu-poc_v2-standalone/examples/input_valid.txt
echo "invalid command format" > brok-clu-poc_v2-standalone/examples/input_invalid.txt

# 8. Make binaries executable
chmod +x brok-clu-poc_v2-standalone/bin/*
chmod +x brok-clu-poc_v2-standalone/bundles/release/bin/*

# 9. Copy scripts (from Phase 10 implementation)
# 10. Copy documentation (from Phase 10 implementation)
# 11. Generate MANIFEST.txt and SHA256SUMS
# 12. Run validation tests
```

## Freeze Date

Bundle frozen: Phase 10 patch completion
