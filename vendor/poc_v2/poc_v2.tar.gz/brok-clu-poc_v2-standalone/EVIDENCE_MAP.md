# Evidence Map

This document maps claims to concrete evidence artifact paths within the bundle.

## Bundle Integrity Evidence

| Claim | Evidence Path |
|-------|---------------|
| File manifest complete | `MANIFEST.txt` |
| File checksums valid | `SHA256SUMS` |
| Verification passed | `bundles/verified/verify.status.txt` (content: `OK`) |
| Verification log | `bundles/verified/verify.log` |
| Verified manifest copy | `bundles/verified/verify.manifest.txt` |
| Verified checksums copy | `bundles/verified/verify.sha256` |

## Verification Coverage

**Scope:** Full-bundle verification (18 files)

All files listed in `MANIFEST.txt` are integrity-checked via `SHA256SUMS`. This includes:
- Application binaries (`bin/cmd_interpreter`, `bin/safety_parser`)
- Runtime binary (`bundles/release/bin/run_infer`)
- Model files (`bundles/release/model.json`, `bundles/release/weights.bin`, `bundles/release/memory_plan.json`)
- Configuration files (`shared/phase7_adapter/runtime_cmd.conf`, `apps/safety_parser/policy.conf`)
- Scripts (`scripts/verify.sh`, `scripts/run.sh`, `scripts/relocation_test.sh`)
- Examples (`examples/input_valid.txt`, `examples/input_invalid.txt`)
- Documentation (`README.md`, `VERIFY.md`, `VERSION.txt`, `EVIDENCE_MAP.md`, `FREEZE_ATTESTATION.md`)

**Not covered by verification:**
- `artifacts/` directory (generated outputs, not shipped content)
- `bundles/verified/` directory (verification outputs, created by verify.sh)

## Runtime Component Evidence

| Component | Evidence Path |
|-----------|---------------|
| cmd_interpreter binary | `bin/cmd_interpreter` |
| safety_parser binary | `bin/safety_parser` |
| Runtime binary (canonical) | `bundles/release/bin/run_infer` |
| Model configuration | `bundles/release/model.json` |
| Model weights | `bundles/release/weights.bin` |
| Memory plan | `bundles/release/memory_plan.json` |
| Runtime command config | `shared/phase7_adapter/runtime_cmd.conf` |
| Safety policy | `apps/safety_parser/policy.conf` |

## Sample Run Evidence (cmd_interpreter)

After running `./scripts/run.sh examples/input_valid.txt`:

| Evidence Type | Path |
|---------------|------|
| Input copy | `artifacts/runs/run_001/input.txt` |
| Authoritative output | `artifacts/runs/run_001/stdout.raw.kv` |
| Standard error | `artifacts/runs/run_001/stderr.txt` |
| Exit code | `artifacts/runs/run_001/exit_code.txt` |
| Derived JSON | `artifacts/runs/run_001/output.derived.json` |

After running `./scripts/run.sh examples/input_invalid.txt`:

| Evidence Type | Path |
|---------------|------|
| Input copy | `artifacts/runs/run_002/input.txt` |
| Authoritative output | `artifacts/runs/run_002/stdout.raw.kv` |
| Standard error | `artifacts/runs/run_002/stderr.txt` |
| Exit code | `artifacts/runs/run_002/exit_code.txt` |
| Derived JSON | `artifacts/runs/run_002/output.derived.json` |

## Safety Parser Evidence

After running `./scripts/run.sh --safety examples/input_valid.txt`:

| Evidence Type | Path |
|---------------|------|
| Input copy | `artifacts/safety/run_001/input.txt` |
| Authoritative output | `artifacts/safety/run_001/stdout.raw.kv` |
| Standard error | `artifacts/safety/run_001/stderr.txt` |
| Exit code | `artifacts/safety/run_001/exit_code.txt` |
| Derived JSON | `artifacts/safety/run_001/output.derived.json` |

## Determinism Evidence

After running `./scripts/run.sh --determinism-test examples/input_valid.txt --runs 100`:

| Evidence Type | Path |
|---------------|------|
| Test report | `artifacts/determinism/report.txt` |
| Baseline output | `artifacts/determinism/runs/run_001/stdout.raw.kv` |
| All run outputs | `artifacts/determinism/runs/run_XXX/stdout.raw.kv` (001-100) |

**Report format:**
```
determinism_test_result
input_file=examples/input_valid.txt
total_runs=100
failures=0
verdict=PASS
```

## Relocation Evidence

After running `./scripts/relocation_test.sh`:

| Evidence Type | Path |
|---------------|------|
| Relocation report | `artifacts/relocation_test/relocation_report.txt` |
| Verify output | `artifacts/relocation_test/verify_output.txt` |
| Valid run output | `artifacts/relocation_test/run_valid_output.txt` |
| Invalid run output | `artifacts/relocation_test/run_invalid_output.txt` |
| Determinism output | `artifacts/relocation_test/determinism_output.txt` |

**Report format:**
```
relocation_test_report
source_bundle=<original_path>
relocated_to=<temp_path>
step=verification
verify_result=PASS
...
test_verdict=PASS
all_tests_passed=yes
```

## Cross-Reference to PoC v1

This bundle is derived from PoC v1 artifacts (immutable input):

| PoC v2 Location | PoC v1 Source |
|-----------------|---------------|
| `bin/cmd_interpreter` | `dist/poc_v1/bin/macos-arm64/cmd_interpreter` |
| `bin/safety_parser` | `dist/poc_v1/bin/macos-arm64/safety_parser` |
| `bundles/release/bin/run_infer` | Built from `runtime/src/run_infer.c` |
| `bundles/release/model.json` | `model/export/runtime/runtime_model.json` |
| `bundles/release/weights.bin` | `model/export/runtime/weights.bin` |
| `bundles/release/memory_plan.json` | `model/export/runtime/memory_plan.json` |
| `apps/safety_parser/policy.conf` | `apps/safety_parser/policy.conf` |

**Attestation:** PoC v1 artifacts were not modified. Binaries are byte-identical copies.
